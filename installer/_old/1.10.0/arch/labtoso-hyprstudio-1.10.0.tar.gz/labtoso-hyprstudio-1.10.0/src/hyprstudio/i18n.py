TEXT = {
    "de": {
        "tab.hypr": "Hyprland", "tab.waybar": "Waybar",
        "sec.keys": "Tastenkürzel", "card.keys": "Tastenkürzel",
        "act.exec": "Programm starten", "act.close": "Fenster schließen", "act.fullscreen": "Vollbild",
        "act.float": "Schweben umschalten", "act.focus": "Fokus bewegen", "act.workspace": "Zur Arbeitsfläche",
        "act.movetows": "Fenster verschieben nach", "act.special": "Scratchpad", "act.togglesplit": "Teilung drehen",
        "dir.left": "Links", "dir.right": "Rechts", "dir.up": "Oben", "dir.down": "Unten",
        "mod.SUPER": "Super", "mod.SHIFT": "Shift", "mod.CTRL": "Strg", "mod.ALT": "Alt",
        "keys.add": "+ Kürzel", "keys.defaults": "Standard laden", "keys.fix": "Konflikte auskommentieren",
        "keys.press": "Taste drücken …", "keys.none": "Taste", "keys.remove": "Entfernen",
        "keys.dup": "Doppelt belegt", "keys.conflict": "Auch in hyprland.lua belegt",
        "keys.count": "{n} aktiv", "keys.fixed": "{n} Kürzel in hyprland.lua auskommentiert",
        "tip.keys.fix": "Kommentiert gleich belegte hl.bind-Zeilen in hyprland.lua aus (mit Sicherung)",
        "tip.keys.defaults": "Übliche Kürzel (Terminal, Fenster, Arbeitsflächen) hinzufügen",
        "sec.presets": "Presets", "sec.windows": "Fenster", "sec.colors": "Farben", "sec.effects": "Effekte",
        "sec.anim": "Animationen", "sec.input": "Eingabe",
        "sec.bar": "Leiste", "sec.modules": "Module", "sec.style": "Farben & Schrift",
        "apply": "Anwenden", "undo": "Rückgängig", "play": "Abspielen", "reset": "Standard",
        "ready": "Bereit", "done": "Angewendet", "failed": "Fehlgeschlagen", "undone": "Rückgängig gemacht",
        "nothing": "Nichts zum Rückgängigmachen", "testmode": "Testmodus – schreibt nur in den Cache",
        "nohypr": "Keine hyprland.lua oder hyprland.conf gefunden", "nowaybar": "Waybar nicht installiert",
        "fmt.lua": "Lua (0.55+)", "fmt.conf": "hyprlang", "fmt.none": "nicht gefunden",
        "log": "Protokoll", "settings": "Einstellungen", "language": "Sprache", "theme": "Farbe",
        "close": "Schließen", "minimize": "Minimieren",
        # Hyprland
        "gaps_in": "Lücke innen", "gaps_out": "Lücke außen", "border_size": "Rahmen", "layout": "Layout",
        "rounding": "Eckenradius", "rounding_power": "Eckenform",
        "active": "Aktiver Rahmen", "active2": "Verlauf bis", "gradient": "Verlauf", "angle": "Winkel",
        "inactive": "Inaktiver Rahmen", "shadow_color": "Schattenfarbe",
        "active_opacity": "Deckkraft aktiv", "inactive_opacity": "Deckkraft inaktiv",
        "dim_inactive": "Inaktive abdunkeln", "dim_strength": "Abdunkeln",
        "blur": "Unschärfe", "blur_size": "Stärke", "blur_passes": "Durchgänge", "blur_vibrancy": "Sättigung",
        "shadow": "Schatten", "shadow_range": "Größe", "shadow_power": "Weichheit",
        "anim": "Animationen", "anim_curve": "Kurve", "anim_tempo": "Tempo", "win_style": "Fenster",
        "ws_style": "Arbeitsflächen",
        "curve.smooth": "Weich", "curve.fast": "Schnell", "curve.bouncy": "Federnd", "curve.linear": "Linear",
        "win.popin": "Aufploppen", "win.slide": "Gleiten", "win.gnomed": "Zoomen",
        "ws.slide": "Seitlich", "ws.slidevert": "Senkrecht", "ws.fade": "Blenden", "ws.slidefade": "Gleitend",
        "kb_layout": "Tastatur", "sensitivity": "Mausempfindlichkeit", "follow_mouse": "Fokus folgt Maus",
        "natural_scroll": "Natürliches Scrollen", "no_logo": "Hyprland-Logo aus",
        "layout.dwindle": "Dwindle", "layout.master": "Master",
        "fm.0": "Aus", "fm.1": "Immer", "fm.2": "Klick",
        "card.gaps": "Abstände", "card.border": "Rahmen & Ecken", "card.layout": "Layout",
        "card.border_col": "Rahmenfarben", "card.shadow": "Schatten", "card.opacity": "Deckkraft",
        "card.blur": "Unschärfe", "card.anim": "Bewegung", "card.kb": "Tastatur", "card.misc": "Sonstiges",
        "p.hyprland": "Hyprland", "p.tokyo": "Tokyo Night", "p.catppuccin": "Catppuccin", "p.nord": "Nord",
        "p.gruvbox": "Gruvbox", "p.rosepine": "Rosé Pine", "p.dracula": "Dracula", "p.glass": "Glas",
        "p.minimal": "Minimal",
        # Waybar
        "position": "Position", "pos.top": "Oben", "pos.bottom": "Unten",
        "style": "Form", "st.bar": "Leiste", "st.float": "Schwebend", "st.islands": "Inseln",
        "height": "Höhe", "margin": "Abstand", "radius": "Eckenradius", "spacing": "Modul-Abstand",
        "bg": "Hintergrund", "fg": "Text", "accent": "Akzent", "border": "Rahmenfarbe", "border_width": "Rahmen",
        "font": "Schrift", "font_size": "Schriftgröße", "icons": "Symbole (Nerd Font)", "clock24": "24-Stunden-Uhr",
        "launcher": "Launcher-Befehl", "from_hypr": "Farben von Hyprland",
        "card.shape": "Form", "card.size": "Größe", "card.colors": "Farben", "card.font": "Schrift",
        "card.extra": "Sonstiges",
        "col.left": "Links", "col.center": "Mitte", "col.right": "Rechts", "col.avail": "Verfügbar",
        "wp.float": "Schwebend", "wp.islands": "Inseln", "wp.classic": "Klassisch", "wp.minimal": "Minimal",
        "wp.bottom": "Unten", "wp.glass": "Glas",
        "m.custom/launcher": "Launcher", "m.hyprland/workspaces": "Arbeitsflächen", "m.hyprland/window": "Fenstertitel",
        "m.clock": "Uhr", "m.pulseaudio": "Lautstärke", "m.network": "Netzwerk", "m.battery": "Akku",
        "m.backlight": "Helligkeit", "m.bluetooth": "Bluetooth", "m.cpu": "CPU", "m.memory": "RAM",
        "m.temperature": "Temperatur", "m.tray": "Tray",
        "tip.rounding_power": "2 = rund, 4 = Squircle",
        "tip.anim_tempo": "Höher = schneller",
        "tip.kb_layout": "z. B. de, us, de,us",
        "tip.modules": "Module per Ziehen zwischen den Spalten verschieben",
        "tip.undo": "Stellt die vorige Version wieder her",
    },
    "en": {
        "tab.hypr": "Hyprland", "tab.waybar": "Waybar",
        "sec.keys": "Shortcuts", "card.keys": "Shortcuts",
        "act.exec": "Launch program", "act.close": "Close window", "act.fullscreen": "Fullscreen",
        "act.float": "Toggle floating", "act.focus": "Move focus", "act.workspace": "Go to workspace",
        "act.movetows": "Move window to", "act.special": "Scratchpad", "act.togglesplit": "Toggle split",
        "dir.left": "Left", "dir.right": "Right", "dir.up": "Up", "dir.down": "Down",
        "mod.SUPER": "Super", "mod.SHIFT": "Shift", "mod.CTRL": "Ctrl", "mod.ALT": "Alt",
        "keys.add": "+ Shortcut", "keys.defaults": "Load defaults", "keys.fix": "Comment out conflicts",
        "keys.press": "Press keys …", "keys.none": "Key", "keys.remove": "Remove",
        "keys.dup": "Used twice", "keys.conflict": "Also bound in hyprland.lua",
        "keys.count": "{n} active", "keys.fixed": "{n} shortcuts commented out in hyprland.lua",
        "tip.keys.fix": "Comments out matching hl.bind lines in hyprland.lua (with backup)",
        "tip.keys.defaults": "Add common shortcuts (terminal, windows, workspaces)",
        "sec.presets": "Presets", "sec.windows": "Windows", "sec.colors": "Colours", "sec.effects": "Effects",
        "sec.anim": "Animations", "sec.input": "Input",
        "sec.bar": "Bar", "sec.modules": "Modules", "sec.style": "Colours & font",
        "apply": "Apply", "undo": "Undo", "play": "Play", "reset": "Default",
        "ready": "Ready", "done": "Applied", "failed": "Failed", "undone": "Undone",
        "nothing": "Nothing to undo", "testmode": "Test mode – writes to the cache only",
        "nohypr": "No hyprland.lua or hyprland.conf found", "nowaybar": "Waybar not installed",
        "fmt.lua": "Lua (0.55+)", "fmt.conf": "hyprlang", "fmt.none": "not found",
        "log": "Log", "settings": "Settings", "language": "Language", "theme": "Colour",
        "close": "Close", "minimize": "Minimise",
        "gaps_in": "Inner gap", "gaps_out": "Outer gap", "border_size": "Border", "layout": "Layout",
        "rounding": "Corner radius", "rounding_power": "Corner shape",
        "active": "Active border", "active2": "Gradient to", "gradient": "Gradient", "angle": "Angle",
        "inactive": "Inactive border", "shadow_color": "Shadow colour",
        "active_opacity": "Active opacity", "inactive_opacity": "Inactive opacity",
        "dim_inactive": "Dim inactive", "dim_strength": "Dim amount",
        "blur": "Blur", "blur_size": "Strength", "blur_passes": "Passes", "blur_vibrancy": "Vibrancy",
        "shadow": "Shadow", "shadow_range": "Size", "shadow_power": "Softness",
        "anim": "Animations", "anim_curve": "Curve", "anim_tempo": "Tempo", "win_style": "Windows",
        "ws_style": "Workspaces",
        "curve.smooth": "Smooth", "curve.fast": "Fast", "curve.bouncy": "Bouncy", "curve.linear": "Linear",
        "win.popin": "Pop in", "win.slide": "Slide", "win.gnomed": "Zoom",
        "ws.slide": "Sideways", "ws.slidevert": "Vertical", "ws.fade": "Fade", "ws.slidefade": "Slide fade",
        "kb_layout": "Keyboard", "sensitivity": "Mouse sensitivity", "follow_mouse": "Focus follows mouse",
        "natural_scroll": "Natural scrolling", "no_logo": "Hide Hyprland logo",
        "layout.dwindle": "Dwindle", "layout.master": "Master",
        "fm.0": "Off", "fm.1": "Always", "fm.2": "Click",
        "card.gaps": "Gaps", "card.border": "Border & corners", "card.layout": "Layout",
        "card.border_col": "Border colours", "card.shadow": "Shadow", "card.opacity": "Opacity",
        "card.blur": "Blur", "card.anim": "Motion", "card.kb": "Keyboard", "card.misc": "Misc",
        "p.hyprland": "Hyprland", "p.tokyo": "Tokyo Night", "p.catppuccin": "Catppuccin", "p.nord": "Nord",
        "p.gruvbox": "Gruvbox", "p.rosepine": "Rosé Pine", "p.dracula": "Dracula", "p.glass": "Glass",
        "p.minimal": "Minimal",
        "position": "Position", "pos.top": "Top", "pos.bottom": "Bottom",
        "style": "Shape", "st.bar": "Bar", "st.float": "Floating", "st.islands": "Islands",
        "height": "Height", "margin": "Margin", "radius": "Corner radius", "spacing": "Module spacing",
        "bg": "Background", "fg": "Text", "accent": "Accent", "border": "Border colour", "border_width": "Border",
        "font": "Font", "font_size": "Font size", "icons": "Icons (Nerd Font)", "clock24": "24-hour clock",
        "launcher": "Launcher command", "from_hypr": "Colours from Hyprland",
        "card.shape": "Shape", "card.size": "Size", "card.colors": "Colours", "card.font": "Font",
        "card.extra": "Misc",
        "col.left": "Left", "col.center": "Centre", "col.right": "Right", "col.avail": "Available",
        "wp.float": "Floating", "wp.islands": "Islands", "wp.classic": "Classic", "wp.minimal": "Minimal",
        "wp.bottom": "Bottom", "wp.glass": "Glass",
        "m.custom/launcher": "Launcher", "m.hyprland/workspaces": "Workspaces", "m.hyprland/window": "Window title",
        "m.clock": "Clock", "m.pulseaudio": "Volume", "m.network": "Network", "m.battery": "Battery",
        "m.backlight": "Brightness", "m.bluetooth": "Bluetooth", "m.cpu": "CPU", "m.memory": "RAM",
        "m.temperature": "Temperature", "m.tray": "Tray",
        "tip.rounding_power": "2 = round, 4 = squircle",
        "tip.anim_tempo": "Higher = faster",
        "tip.kb_layout": "e.g. de, us, de,us",
        "tip.modules": "Drag modules between the columns",
        "tip.undo": "Restores the previous version",
    },
}

# Erweiterungen ab 1.2
_DE_MORE = {
    "sec.system": "System",
    "smart_gaps": "Keine Lücken bei 1 Fenster", "resize_on_border": "Größe am Rand ziehen",
    "card.dwindle": "Dwindle", "card.master": "Master",
    "dwindle_preserve": "Teilung behalten", "dwindle_force": "Neues Fenster", "dwindle_smart": "Teilung nach Maus",
    "force.0": "Maus", "force.1": "Links/Oben", "force.2": "Rechts/Unten",
    "master_new": "Neues Fenster wird", "mnew.master": "Master", "mnew.slave": "Stapel", "mnew.inherit": "Wie aktiv",
    "master_mfact": "Master-Breite", "master_orient": "Master-Seite",
    "orient.left": "Links", "orient.right": "Rechts", "orient.top": "Oben", "orient.bottom": "Unten",
    "orient.center": "Mitte",
    "border_rotate": "Verlauf dreht sich", "border_rotate_speed": "Dreh-Dauer",
    "card.background": "Hintergrund", "bg_color": "Hintergrundfarbe",
    "blur_noise": "Rauschen", "blur_contrast": "Kontrast", "blur_brightness": "Helligkeit",
    "blur_xray": "Röntgen-Modus", "blur_ignore_opacity": "Deckkraft ignorieren", "shadow_sharp": "Harter Schatten",
    "card.anim_parts": "Bereiche", "anim_windows": "Fenster", "anim_fade": "Überblenden",
    "anim_ws": "Arbeitsflächen", "anim_border": "Rahmen", "anim_layers": "Ebenen (Leisten, Menüs)",
    "kb_variant": "Variante", "kb_options": "Optionen", "numlock": "Num-Lock beim Start",
    "repeat_rate": "Wiederholrate", "repeat_delay": "Verzögerung",
    "card.mouse": "Maus", "accel": "Beschleunigung", "accel.default": "Standard", "accel.flat": "Flach",
    "accel.adaptive": "Adaptiv", "left_handed": "Linkshänder",
    "card.touchpad": "Touchpad", "dwt": "Aus beim Tippen", "scroll_factor": "Scroll-Tempo",
    "gesture": "Wischen für Arbeitsflächen", "gest.0": "Nicht setzen", "gest.3": "3 Finger", "gest.4": "4 Finger",
    "card.cursor": "Mauszeiger", "cursor_size": "Größe", "cursor_theme": "Thema",
    "cursor_timeout": "Ausblenden nach", "cursor_hide_keys": "Beim Tippen ausblenden",
    "card.autostart": "Autostart", "autostart_waybar": "Waybar starten", "autostart": "Programme",
    "card.monitor": "Monitor", "monitor_on": "Monitor einstellen", "monitor_mode": "Modus",
    "mmode.preferred": "Empfohlen", "mmode.highrr": "Max. Hz", "mmode.highres": "Max. Auflösung",
    "monitor_scale": "Skalierung", "scale.auto": "Auto", "scale.1": "100 %", "scale.1.25": "125 %",
    "scale.1.5": "150 %", "scale.2": "200 %",
    "focus_on_activate": "Fokus bei Aktivierung", "swallow": "Terminal verschlucken",
    "swallow_regex": "Terminal-Klassen", "mmb_paste": "Mittelklick einfügen",
    "dpms_mouse": "Maus weckt Bildschirm", "dpms_key": "Taste weckt Bildschirm",
    "tip.smart_gaps": "Ist nur ein Fenster offen, fallen Lücken, Rahmen und Ecken weg",
    "tip.dwindle_smart": "Die Teilung richtet sich nach der Mausposition",
    "tip.border_rotate": "Lässt den Rahmen-Verlauf ständig rotieren",
    "tip.border_rotate_speed": "Dauer einer Umdrehung (höher = langsamer)",
    "tip.blur_xray": "Unscharfe Fenster zeigen nur den Hintergrund, nicht die Fenster darunter",
    "tip.kb_variant": "z. B. nodeadkeys", "tip.kb_options": "z. B. caps:escape, grp:alt_shift_toggle",
    "tip.gesture": "Fügt eine Wisch-Geste hinzu; „Nicht setzen“ lässt deine eigene Config bestimmen",
    "tip.cursor_theme": "z. B. Bibata-Modern-Classic (leer = nicht ändern)",
    "tip.cursor_timeout": "0 = nie ausblenden",
    "tip.autostart": "Ein Befehl pro Zeile, startet einmal beim Login",
    "tip.monitor_on": "Setzt Modus und Skalierung für alle Monitore",
    "tip.swallow": "Startet ein Programm aus dem Terminal, ersetzt sein Fenster das Terminal",
}
_EN_MORE = {
    "sec.system": "System",
    "smart_gaps": "No gaps with 1 window", "resize_on_border": "Resize by dragging border",
    "card.dwindle": "Dwindle", "card.master": "Master",
    "dwindle_preserve": "Preserve split", "dwindle_force": "New window", "dwindle_smart": "Split by mouse",
    "force.0": "Mouse", "force.1": "Left/Top", "force.2": "Right/Bottom",
    "master_new": "New window becomes", "mnew.master": "Master", "mnew.slave": "Stack", "mnew.inherit": "Like active",
    "master_mfact": "Master width", "master_orient": "Master side",
    "orient.left": "Left", "orient.right": "Right", "orient.top": "Top", "orient.bottom": "Bottom",
    "orient.center": "Centre",
    "border_rotate": "Rotating gradient", "border_rotate_speed": "Rotation time",
    "card.background": "Background", "bg_color": "Background colour",
    "blur_noise": "Noise", "blur_contrast": "Contrast", "blur_brightness": "Brightness",
    "blur_xray": "X-ray mode", "blur_ignore_opacity": "Ignore opacity", "shadow_sharp": "Sharp shadow",
    "card.anim_parts": "Parts", "anim_windows": "Windows", "anim_fade": "Fade",
    "anim_ws": "Workspaces", "anim_border": "Border", "anim_layers": "Layers (bars, menus)",
    "kb_variant": "Variant", "kb_options": "Options", "numlock": "Num Lock on start",
    "repeat_rate": "Repeat rate", "repeat_delay": "Repeat delay",
    "card.mouse": "Mouse", "accel": "Acceleration", "accel.default": "Default", "accel.flat": "Flat",
    "accel.adaptive": "Adaptive", "left_handed": "Left-handed",
    "card.touchpad": "Touchpad", "dwt": "Off while typing", "scroll_factor": "Scroll speed",
    "gesture": "Swipe for workspaces", "gest.0": "Don't set", "gest.3": "3 fingers", "gest.4": "4 fingers",
    "card.cursor": "Cursor", "cursor_size": "Size", "cursor_theme": "Theme",
    "cursor_timeout": "Hide after", "cursor_hide_keys": "Hide while typing",
    "card.autostart": "Autostart", "autostart_waybar": "Start Waybar", "autostart": "Programs",
    "card.monitor": "Monitor", "monitor_on": "Configure monitor", "monitor_mode": "Mode",
    "mmode.preferred": "Preferred", "mmode.highrr": "Max Hz", "mmode.highres": "Max resolution",
    "monitor_scale": "Scale", "scale.auto": "Auto", "scale.1": "100 %", "scale.1.25": "125 %",
    "scale.1.5": "150 %", "scale.2": "200 %",
    "focus_on_activate": "Focus on activate", "swallow": "Swallow terminal",
    "swallow_regex": "Terminal classes", "mmb_paste": "Middle-click paste",
    "dpms_mouse": "Mouse wakes screen", "dpms_key": "Key wakes screen",
    "tip.smart_gaps": "With only one window, gaps, border and corners are removed",
    "tip.dwindle_smart": "The split follows the mouse position",
    "tip.border_rotate": "Keeps the border gradient rotating",
    "tip.border_rotate_speed": "Time for one turn (higher = slower)",
    "tip.blur_xray": "Blurred windows show only the wallpaper, not windows below",
    "tip.kb_variant": "e.g. nodeadkeys", "tip.kb_options": "e.g. caps:escape, grp:alt_shift_toggle",
    "tip.gesture": "Adds a swipe gesture; “Don't set” leaves it to your own config",
    "tip.cursor_theme": "e.g. Bibata-Modern-Classic (empty = don't change)",
    "tip.cursor_timeout": "0 = never hide",
    "tip.autostart": "One command per line, runs once at login",
    "tip.monitor_on": "Sets mode and scale for all monitors",
    "tip.swallow": "A program started from the terminal replaces the terminal window",
}
TEXT["de"].update(_DE_MORE)
TEXT["de"].update({'act.kill': 'Fenster hart beenden', 'act.pseudo': 'Pseudo-Kachel', 'act.movewin': 'Fenster schieben', 'act.wsnext': 'Nächste Arbeitsfläche', 'act.wsprev': 'Vorige Arbeitsfläche', 'act.movespecial': 'In Scratchpad legen', 'act.drag': 'Fenster ziehen (Maus)', 'act.resize': 'Größe ändern (Maus)', 'act.exit': 'Hyprland beenden', 'flag.locked': 'Auch im Sperrbildschirm', 'flag.repeating': 'Wiederholen beim Halten', 'flag.release': 'Erst beim Loslassen', 'keys.flags': 'Optionen', 'keys.duplicate': 'Duplizieren', 'keys.manual': 'Von Hand eingeben …', 'keys.manual_q': 'Tastenname (z. B. Return, F5, mouse:274)', 'keys.templates': 'Vorlagen', 'keys.import': 'Aus Config übernehmen', 'keys.imported': '{n} Kürzel aus der Config übernommen', 'search': 'Suchen', 'tip.keys.import': 'Liest deine Kürzel aus hyprland.lua/.conf, kommentiert sie dort aus (mit Sicherung) und wendet an', 'tip.keybtn': 'Klicken und Kombination drücken · Rechtsklick: Maustasten, Medientasten, von Hand', 'tpl.basics': 'Grundlagen', 'tpl.focus': 'Fokus mit Pfeilen', 'tpl.move': 'Fenster mit Pfeilen schieben', 'tpl.workspaces': 'Arbeitsflächen 1–10', 'tpl.special': 'Scratchpad', 'tpl.mouse': 'Maus', 'tpl.media': 'Lautstärke, Helligkeit, Medien', 'tpl.screenshot': 'Screenshot & Farbpipette', 'tpl.all': 'Alles', 'key.mouse:272': 'Linke Maustaste', 'key.mouse:273': 'Rechte Maustaste', 'key.mouse_down': 'Mausrad runter', 'key.mouse_up': 'Mausrad hoch', 'key.Print': 'Druck', 'key.space': 'Leertaste', 'key.Return': 'Enter', 'key.Escape': 'Esc', 'key.XF86AudioRaiseVolume': 'Lauter', 'key.XF86AudioLowerVolume': 'Leiser', 'key.XF86AudioMute': 'Stumm', 'key.XF86AudioMicMute': 'Mikro stumm', 'key.XF86AudioPlay': 'Play/Pause', 'key.XF86AudioNext': 'Nächster Titel', 'key.XF86AudioPrev': 'Voriger Titel', 'key.XF86MonBrightnessUp': 'Heller', 'key.XF86MonBrightnessDown': 'Dunkler', 'key.XF86PowerOff': 'Power-Taste', 'key.XF86Calculator': 'Rechner-Taste'})
TEXT["en"].update(_EN_MORE)
TEXT["en"].update({'act.kill': 'Force kill window', 'act.pseudo': 'Pseudotile', 'act.movewin': 'Move window', 'act.wsnext': 'Next workspace', 'act.wsprev': 'Previous workspace', 'act.movespecial': 'Send to scratchpad', 'act.drag': 'Drag window (mouse)', 'act.resize': 'Resize (mouse)', 'act.exit': 'Exit Hyprland', 'flag.locked': 'Also on lock screen', 'flag.repeating': 'Repeat while held', 'flag.release': 'Only on release', 'keys.flags': 'Options', 'keys.duplicate': 'Duplicate', 'keys.manual': 'Type manually …', 'keys.manual_q': 'Key name (e.g. Return, F5, mouse:274)', 'keys.templates': 'Templates', 'keys.import': 'Import from config', 'keys.imported': '{n} shortcuts imported from the config', 'search': 'Search', 'tip.keys.import': 'Reads your shortcuts from hyprland.lua/.conf, comments them out there (with backup) and applies', 'tip.keybtn': 'Click and press a combination · right-click: mouse, media keys, manual', 'tpl.basics': 'Basics', 'tpl.focus': 'Focus with arrows', 'tpl.move': 'Move windows with arrows', 'tpl.workspaces': 'Workspaces 1–10', 'tpl.special': 'Scratchpad', 'tpl.mouse': 'Mouse', 'tpl.media': 'Volume, brightness, media', 'tpl.screenshot': 'Screenshot & colour picker', 'tpl.all': 'Everything', 'key.mouse:272': 'Left mouse button', 'key.mouse:273': 'Right mouse button', 'key.mouse_down': 'Wheel down', 'key.mouse_up': 'Wheel up', 'key.Print': 'Print', 'key.space': 'Space', 'key.Return': 'Enter', 'key.Escape': 'Esc', 'key.XF86AudioRaiseVolume': 'Volume up', 'key.XF86AudioLowerVolume': 'Volume down', 'key.XF86AudioMute': 'Mute', 'key.XF86AudioMicMute': 'Mic mute', 'key.XF86AudioPlay': 'Play/Pause', 'key.XF86AudioNext': 'Next track', 'key.XF86AudioPrev': 'Previous track', 'key.XF86MonBrightnessUp': 'Brighter', 'key.XF86MonBrightnessDown': 'Darker', 'key.XF86PowerOff': 'Power key', 'key.XF86Calculator': 'Calculator key'})

TEXT["de"].update({'sec.options': 'Modul-Optionen', 'layer': 'Ebene', 'layer.top': 'Über Fenstern', 'layer.bottom': 'Unter Fenstern', 'exclusive': 'Platz reservieren', 'pad': 'Innenabstand', 'power_cmd': 'Power-Befehl', 'vol_click': 'Klick auf Lautstärke', 'card.ws': 'Arbeitsflächen', 'ws_format': 'Anzeige', 'wsf.number': 'Zahlen', 'wsf.dot': 'Punkte', 'ws_look': 'Aktive', 'wsl.pill': 'Pille', 'wsl.box': 'Block', 'wsl.underline': 'Unterstrich', 'wsl.text': 'Nur Farbe', 'ws_persist': 'Immer zeigen', 'card.clock': 'Uhr', 'clock_fmt': 'Format', 'cf.hm': '14:32', 'cf.hms': '14:32:05', 'cf.dhm': 'Mo 14:32', 'cf.full': 'Datum + Zeit', 'card.modopts': 'Weitere', 'win_len': 'Fenstertitel max.', 'mpris_len': 'Musiktitel max.', 'net_fmt': 'Netzwerk zeigt', 'net.essid': 'WLAN-Name', 'net.ip': 'IP', 'net.signal': 'Signal', 'vol_step': 'Scroll-Schritt', 'bat_warn': 'Akku Warnung', 'bat_crit': 'Akku kritisch', 'interval': 'Aktualisierung', 'tray_size': 'Tray-Symbolgröße', 'tooltips': 'Tooltips', 'colorful': 'Bunte Module', 'font_weight': 'Stärke', 'fw.normal': 'Normal', 'fw.600': 'Halbfett', 'fw.bold': 'Fett', 'm.disk': 'Speicher', 'm.mpris': 'Musik', 'm.hyprland/language': 'Tastatur-Layout', 'm.idle_inhibitor': 'Wachhalten', 'm.power-profiles-daemon': 'Energieprofil', 'm.custom/power': 'Power', 'wp.rainbow': 'Bunt', 'wp.full': 'Voll', 'tip.layer': 'Unter Fenstern: Vollbild-Fenster verdecken die Leiste', 'tip.exclusive': 'Fenster weichen der Leiste aus', 'tip.ws_persist': 'So viele Arbeitsflächen immer anzeigen (0 = nur belegte)', 'tip.colorful': 'Jedes Modul bekommt eine eigene Farbe'})
TEXT["en"].update({'sec.options': 'Module options', 'layer': 'Layer', 'layer.top': 'Above windows', 'layer.bottom': 'Below windows', 'exclusive': 'Reserve space', 'pad': 'Padding', 'power_cmd': 'Power command', 'vol_click': 'Volume click', 'card.ws': 'Workspaces', 'ws_format': 'Display', 'wsf.number': 'Numbers', 'wsf.dot': 'Dots', 'ws_look': 'Active', 'wsl.pill': 'Pill', 'wsl.box': 'Block', 'wsl.underline': 'Underline', 'wsl.text': 'Colour only', 'ws_persist': 'Always show', 'card.clock': 'Clock', 'clock_fmt': 'Format', 'cf.hm': '14:32', 'cf.hms': '14:32:05', 'cf.dhm': 'Mon 14:32', 'cf.full': 'Date + time', 'card.modopts': 'More', 'win_len': 'Window title max', 'mpris_len': 'Music title max', 'net_fmt': 'Network shows', 'net.essid': 'Wi-Fi name', 'net.ip': 'IP', 'net.signal': 'Signal', 'vol_step': 'Scroll step', 'bat_warn': 'Battery warning', 'bat_crit': 'Battery critical', 'interval': 'Update interval', 'tray_size': 'Tray icon size', 'tooltips': 'Tooltips', 'colorful': 'Colourful modules', 'font_weight': 'Weight', 'fw.normal': 'Normal', 'fw.600': 'Semibold', 'fw.bold': 'Bold', 'm.disk': 'Disk', 'm.mpris': 'Music', 'm.hyprland/language': 'Keyboard layout', 'm.idle_inhibitor': 'Keep awake', 'm.power-profiles-daemon': 'Power profile', 'm.custom/power': 'Power', 'wp.rainbow': 'Colourful', 'wp.full': 'Full', 'tip.layer': 'Below windows: fullscreen windows cover the bar', 'tip.exclusive': 'Windows make room for the bar', 'tip.ws_persist': 'Always show this many workspaces (0 = only used ones)', 'tip.colorful': 'Every module gets its own colour'})

TEXT["de"].update({'tab.launcher': 'Launcher', 'applied': 'Angewendet', 'not_applied': 'Nicht angewendet', 'sec.app': 'Programm', 'sec.window': 'Fenster', 'sec.text': 'Text & Symbole', 'card.app': 'Launcher', 'app': 'Programm', 'app.rofi': 'Rofi', 'app.wofi': 'Wofi', 'app.fuzzel': 'Fuzzel', 'launcher.use': 'Überall als Launcher nutzen', 'launcher.cmd': 'Befehl: {cmd}', 'launcher.missing': '{app} ist nicht installiert', 'launcher.used': '„{cmd}“ in Waybar übernommen, {n} Kürzel angepasst', 'tip.launcher.use': 'Setzt den Befehl für den Waybar-Launcher-Knopf und passt Kürzel an, die einen Launcher starten', 'card.lmode': 'Verhalten', 'mode': 'Zeigt', 'lmode.drun': 'Apps', 'lmode.run': 'Befehle', 'matching': 'Suche', 'match.fuzzy': 'Unscharf', 'match.normal': 'Genau', 'insensitive': 'Groß/klein egal', 'terminal': 'Terminal', 'card.lsize': 'Größe', 'width': 'Breite', 'lines': 'Zeilen', 'grid': 'Raster (Kacheln)', 'columns': 'Spalten', 'icon_size': 'Symbolgröße', 'lspacing': 'Abstand', 'card.lpos': 'Position', 'lpos.center': 'Mitte', 'lpos.top': 'Oben', 'lpos.bottom': 'Unten', 'offset': 'Abstand vom Rand', 'card.lshape': 'Form', 'el_radius': 'Eintrag-Ecken', 'input_bg': 'Suchfeld', 'sel': 'Auswahl', 'sel_fg': 'Auswahl-Text', 'card.ltext': 'Text & Symbole', 'show_prompt': 'Prompt zeigen', 'prompt': 'Prompt', 'placeholder': 'Platzhalter', 'app_icons': 'App-Symbole', 'icon_theme': 'Symbolthema', 'show_scroll': 'Scrollleiste', 'tip.grid': 'Apps als Kacheln mit großen Symbolen (Fuzzel kennt nur Listen)', 'tip.columns': 'Spalten im Raster bzw. in der Liste', 'tip.icon_theme': 'z. B. Papirus-Dark (leer = Systemthema)', 'lp.spotlight': 'Spotlight', 'lp.grid': 'Kacheln', 'lp.compact': 'Kompakt', 'lp.glass': 'Glas', 'lp.tokyo': 'Tokyo Night', 'lp.catppuccin': 'Catppuccin', 'lp.nord': 'Nord', 'lp.gruvbox': 'Gruvbox'})
TEXT["en"].update({'tab.launcher': 'Launcher', 'applied': 'Applied', 'not_applied': 'Not applied', 'sec.app': 'Program', 'sec.window': 'Window', 'sec.text': 'Text & icons', 'card.app': 'Launcher', 'app': 'Program', 'app.rofi': 'Rofi', 'app.wofi': 'Wofi', 'app.fuzzel': 'Fuzzel', 'launcher.use': 'Use as launcher everywhere', 'launcher.cmd': 'Command: {cmd}', 'launcher.missing': '{app} is not installed', 'launcher.used': '“{cmd}” set in Waybar, {n} shortcuts updated', 'tip.launcher.use': 'Sets the Waybar launcher button command and updates shortcuts that start a launcher', 'card.lmode': 'Behaviour', 'mode': 'Shows', 'lmode.drun': 'Apps', 'lmode.run': 'Commands', 'matching': 'Matching', 'match.fuzzy': 'Fuzzy', 'match.normal': 'Exact', 'insensitive': 'Ignore case', 'terminal': 'Terminal', 'card.lsize': 'Size', 'width': 'Width', 'lines': 'Lines', 'grid': 'Grid (tiles)', 'columns': 'Columns', 'icon_size': 'Icon size', 'lspacing': 'Spacing', 'card.lpos': 'Position', 'lpos.center': 'Centre', 'lpos.top': 'Top', 'lpos.bottom': 'Bottom', 'offset': 'Distance from edge', 'card.lshape': 'Shape', 'el_radius': 'Entry corners', 'input_bg': 'Search field', 'sel': 'Selection', 'sel_fg': 'Selection text', 'card.ltext': 'Text & icons', 'show_prompt': 'Show prompt', 'prompt': 'Prompt', 'placeholder': 'Placeholder', 'app_icons': 'App icons', 'icon_theme': 'Icon theme', 'show_scroll': 'Scrollbar', 'tip.grid': 'Apps as tiles with big icons (Fuzzel only does lists)', 'tip.columns': 'Columns in grid or list', 'tip.icon_theme': 'e.g. Papirus-Dark (empty = system theme)', 'lp.spotlight': 'Spotlight', 'lp.grid': 'Tiles', 'lp.compact': 'Compact', 'lp.glass': 'Glass', 'lp.tokyo': 'Tokyo Night', 'lp.catppuccin': 'Catppuccin', 'lp.nord': 'Nord', 'lp.gruvbox': 'Gruvbox'})

TEXT["de"].update({'tab.other': 'Sonstiges', 'sec.fix': 'Reparatur', 'sec.tools': 'Werkzeuge', 'sec.backups': 'Sicherungen', 'fix.scan': 'Fehler suchen', 'fix.all': 'Alle beheben', 'fix.reload': 'Hyprland neu laden', 'fix.one': 'Beheben', 'fix.none': 'Keine Config-Fehler', 'fix.count': '{n} Config-Fehler', 'fix.nofile': 'Ohne Datei/Zeile', 'fix.done': '{n} behoben, {left} übrig', 'fix.startup': '{n} Config-Fehler gefunden – unter Sonstiges › Reparatur beheben', 'fix.tip.skip': 'Hypr Studio schreibt die Option „{opt}“ nicht mehr (deine Hyprland-Version kennt sie nicht)', 'fix.tip.state': 'Schaltet die betroffene Funktion in Hypr Studio ab und wendet neu an', 'fix.tip.bind': 'Entfernt das fehlerhafte Kürzel und wendet neu an', 'fix.tip.comment': 'Kommentiert die Zeile in deiner Datei aus (mit Sicherung)', 'fix.tip.none': 'Zu dieser Meldung gibt es keine Datei/Zeile', 'tool.reload': 'Hyprland neu laden', 'tool.waybar': 'Waybar neu starten', 'tool.open_hypr': 'Hyprland-Ordner öffnen', 'tool.open_waybar': 'Waybar-Ordner öffnen', 'tool.open_launcher': 'Launcher-Ordner öffnen', 'tool.open_backups': 'Sicherungen anzeigen', 'bak.refresh': 'Aktualisieren', 'bak.restore': 'Wiederherstellen', 'bak.none': 'Keine Sicherungen gefunden', 'bak.tip': 'Kopiert die Sicherung zurück nach {target} (die aktuelle Datei wird vorher gesichert)', 'bak.confirm': '{src} nach {target} zurückkopieren?\nDie aktuelle Datei wird vorher gesichert.', 'bak.done': '{target} wiederhergestellt'})
TEXT["en"].update({'tab.other': 'More', 'sec.fix': 'Repair', 'sec.tools': 'Tools', 'sec.backups': 'Backups', 'fix.scan': 'Find errors', 'fix.all': 'Fix all', 'fix.reload': 'Reload Hyprland', 'fix.one': 'Fix', 'fix.none': 'No config errors', 'fix.count': '{n} config errors', 'fix.nofile': 'No file/line', 'fix.done': '{n} fixed, {left} left', 'fix.startup': '{n} config errors found – fix them under More › Repair', 'fix.tip.skip': "Hypr Studio stops writing the option “{opt}” (your Hyprland version doesn't know it)", 'fix.tip.state': 'Turns off the affected feature in Hypr Studio and re-applies', 'fix.tip.bind': 'Removes the broken shortcut and re-applies', 'fix.tip.comment': 'Comments out the line in your file (with backup)', 'fix.tip.none': 'This message has no file/line', 'tool.reload': 'Reload Hyprland', 'tool.waybar': 'Restart Waybar', 'tool.open_hypr': 'Open Hyprland folder', 'tool.open_waybar': 'Open Waybar folder', 'tool.open_launcher': 'Open launcher folder', 'tool.open_backups': 'Show backups', 'bak.refresh': 'Refresh', 'bak.restore': 'Restore', 'bak.none': 'No backups found', 'bak.tip': 'Copies the backup back to {target} (the current file is backed up first)', 'bak.confirm': 'Copy {src} back to {target}?\nThe current file is backed up first.', 'bak.done': '{target} restored'})

TEXT["de"].update({'card.skip': 'Vom Fixer weggelassen', 'skip_opts': 'Optionen', 'tip.skip_opts': 'Diese Optionen schreibt Hypr Studio nicht (kennt deine Hyprland-Version nicht). Zeile löschen = wieder schreiben'})
TEXT["en"].update({'card.skip': 'Left out by the fixer', 'skip_opts': 'Options', 'tip.skip_opts': "Hypr Studio doesn't write these options (unknown to your Hyprland version). Delete a line to write it again"})

TEXT["de"].update({'reset.section': 'Zurücksetzen', 'reset.button': 'Alles zurücksetzen', 'reset.title': 'Alles zurücksetzen?', 'reset.tip': 'Nimmt alle Änderungen von Hypr Studio aus Hyprland, Waybar und Launcher heraus', 'reset.text': 'Hypr Studio wird aus Hyprland entfernt, ausgeblendete Zeilen in deiner Config werden wieder aktiv, Waybar und Launcher bekommen ihre Original-Config zurück und alle Einstellungen in Hypr Studio gehen auf Standard. Jede geänderte Datei wird vorher gesichert (unter Sonstiges › Sicherungen).', 'reset.factory': 'Auch meine hyprland.lua durch die Hyprland-Standard-Config ersetzen', 'reset.factory_tip': 'Schreibt die offizielle Beispiel-Config; deine Datei wird vorher gesichert', 'reset.factory_off': 'Nur mit Lua-Config (Hyprland 0.55+) möglich', 'reset.sure': 'Ja, ich will wirklich alles zurücksetzen', 'cancel': 'Abbrechen', 'reset.done': 'Alles zurückgesetzt – Sicherungen unter Sonstiges › Sicherungen'})
TEXT["en"].update({'reset.section': 'Reset', 'reset.button': 'Reset everything', 'reset.title': 'Reset everything?', 'reset.tip': 'Removes all Hypr Studio changes from Hyprland, Waybar and the launcher', 'reset.text': 'Hypr Studio is removed from Hyprland, lines it commented out in your config become active again, Waybar and the launcher get their original config back and all Hypr Studio settings go back to default. Every changed file is backed up first (under More › Backups).', 'reset.factory': 'Also replace my hyprland.lua with the Hyprland default config', 'reset.factory_tip': 'Writes the official example config; your file is backed up first', 'reset.factory_off': 'Only possible with a Lua config (Hyprland 0.55+)', 'reset.sure': 'Yes, I really want to reset everything', 'cancel': 'Cancel', 'reset.done': 'Everything reset – backups under More › Backups'})

TEXT["de"].update({'sec.install': 'Installieren', 'pkgg.launcher': 'Launcher', 'pkgg.bar': 'Leiste & Schrift', 'pkgg.tools': 'Werkzeuge', 'pkg.rofi': 'Rofi', 'pkg.wofi': 'Wofi', 'pkg.fuzzel': 'Fuzzel', 'pkg.waybar': 'Waybar', 'pkg.nerdfont': 'JetBrainsMono Nerd Font', 'pkg.pavucontrol': 'Pavucontrol', 'pkg.screenshot': 'Screenshot', 'pkg.media': 'Medientasten', 'pkg.hyprpicker': 'Hyprpicker', 'pkg.hyprlock': 'Hyprlock', 'pkg.hyprpaper': 'Hyprpaper', 'pkg.cliphist': 'Cliphist', 'pkgd.rofi': 'App-Launcher, sehr anpassbar', 'pkgd.wofi': 'schlanker Launcher (GTK)', 'pkgd.fuzzel': 'schneller, minimaler Launcher', 'pkgd.waybar': 'Statusleiste', 'pkgd.nerdfont': 'Schrift mit Symbolen für Waybar', 'pkgd.pavucontrol': 'Lautstärke-Fenster (Klick auf Lautstärke)', 'pkgd.screenshot': 'Bereich auswählen und kopieren', 'pkgd.media': 'Lautstärke-, Helligkeits- und Medientasten', 'pkgd.hyprpicker': 'Farbpipette', 'pkgd.hyprlock': 'Sperrbildschirm', 'pkgd.hyprpaper': 'Hintergrundbild', 'pkgd.cliphist': 'Zwischenablage-Verlauf', 'pkg.installed': 'Installiert', 'pkg.missing': 'Nicht installiert', 'pkg.unavailable': 'Nicht verfügbar', 'pkg.install': '{n} installieren', 'pkg.install0': 'Auswählen zum Installieren', 'pkg.pm': 'Paketmanager: {pm}', 'pkg.nopm': 'Kein unterstützter Paketmanager', 'pkg.busy': 'Wird installiert …', 'pkg.done': 'Installiert', 'pkg.failed': 'Installation fehlgeschlagen – siehe Protokoll', 'pkg.fallback': 'pkexec abgebrochen oder kein Polkit-Agent – öffne Terminal mit sudo', 'pkg.terminal': 'Installation läuft im Terminal ({term})', 'pkg.noterm': 'Kein Terminal gefunden'})
TEXT["en"].update({'sec.install': 'Install', 'pkgg.launcher': 'Launcher', 'pkgg.bar': 'Bar & font', 'pkgg.tools': 'Tools', 'pkg.rofi': 'Rofi', 'pkg.wofi': 'Wofi', 'pkg.fuzzel': 'Fuzzel', 'pkg.waybar': 'Waybar', 'pkg.nerdfont': 'JetBrainsMono Nerd Font', 'pkg.pavucontrol': 'Pavucontrol', 'pkg.screenshot': 'Screenshot', 'pkg.media': 'Media keys', 'pkg.hyprpicker': 'Hyprpicker', 'pkg.hyprlock': 'Hyprlock', 'pkg.hyprpaper': 'Hyprpaper', 'pkg.cliphist': 'Cliphist', 'pkgd.rofi': 'app launcher, very customisable', 'pkgd.wofi': 'lightweight launcher (GTK)', 'pkgd.fuzzel': 'fast, minimal launcher', 'pkgd.waybar': 'status bar', 'pkgd.nerdfont': 'font with icons for Waybar', 'pkgd.pavucontrol': 'volume window (click on volume)', 'pkgd.screenshot': 'select an area and copy it', 'pkgd.media': 'volume, brightness and media keys', 'pkgd.hyprpicker': 'colour picker', 'pkgd.hyprlock': 'lock screen', 'pkgd.hyprpaper': 'wallpaper', 'pkgd.cliphist': 'clipboard history', 'pkg.installed': 'Installed', 'pkg.missing': 'Not installed', 'pkg.unavailable': 'Not available', 'pkg.install': 'Install {n}', 'pkg.install0': 'Select to install', 'pkg.pm': 'Package manager: {pm}', 'pkg.nopm': 'No supported package manager', 'pkg.busy': 'Installing …', 'pkg.done': 'Installed', 'pkg.failed': 'Installation failed – see log', 'pkg.fallback': 'pkexec cancelled or no polkit agent – opening a terminal with sudo', 'pkg.terminal': 'Installing in the terminal ({term})', 'pkg.noterm': 'No terminal found'})

TEXT["de"].update({'keys.press': 'Kombination drücken …', 'keys.max4': 'Höchstens 4 Tasten', 'keys.manual_q': 'Kombination (z. B. Strg + Shift + Alt + A, SUPER + mouse:272)', 'tip.keybtn': 'Klicken und die ganze Kombination drücken (bis zu 4 Tasten, z. B. Strg + Shift + Alt + A) · Rechtsklick: Maus-/Medientasten oder von Hand eingeben'})
TEXT["en"].update({'keys.press': 'Press combination …', 'keys.max4': 'At most 4 keys', 'keys.manual_q': 'Combination (e.g. Ctrl + Shift + Alt + A, SUPER + mouse:272)', 'tip.keybtn': 'Click and press the whole combination (up to 4 keys, e.g. Ctrl + Shift + Alt + A) · right-click: mouse/media keys or type it'})

TEXT["de"].update({'wp.dock': 'Dock', 'wp.neon': 'Neon', 'wp.pills': 'Pillen', 'wp.underline': 'Unterstrich', 'wp.clear': 'Durchsichtig', 'wp.catppuccin': 'Catppuccin', 'wp.nord': 'Nord', 'wp.gruvbox': 'Gruvbox', 'p.everforest': 'Everforest', 'p.kanagawa': 'Kanagawa', 'p.onedark': 'One Dark', 'p.solarized': 'Solarized', 'p.monokai': 'Monokai', 'p.neon': 'Neon', 'p.sharp': 'Kantig', 'p.bubbly': 'Rund & weich', 'p.mono': 'Mono', 'lp.dracula': 'Dracula', 'lp.rosepine': 'Rosé Pine', 'lp.everforest': 'Everforest', 'lp.kanagawa': 'Kanagawa', 'lp.neon': 'Neon', 'lp.topbar': 'Leiste oben', 'lp.bigicons': 'Große Symbole', 'lp.sharp': 'Kantig'})
TEXT["en"].update({'wp.dock': 'Dock', 'wp.neon': 'Neon', 'wp.pills': 'Pills', 'wp.underline': 'Underline', 'wp.clear': 'Transparent', 'wp.catppuccin': 'Catppuccin', 'wp.nord': 'Nord', 'wp.gruvbox': 'Gruvbox', 'p.everforest': 'Everforest', 'p.kanagawa': 'Kanagawa', 'p.onedark': 'One Dark', 'p.solarized': 'Solarized', 'p.monokai': 'Monokai', 'p.neon': 'Neon', 'p.sharp': 'Sharp', 'p.bubbly': 'Soft & round', 'p.mono': 'Mono', 'lp.dracula': 'Dracula', 'lp.rosepine': 'Rosé Pine', 'lp.everforest': 'Everforest', 'lp.kanagawa': 'Kanagawa', 'lp.neon': 'Neon', 'lp.topbar': 'Top bar', 'lp.bigicons': 'Big icons', 'lp.sharp': 'Sharp'})

TEXT["de"].update({'sec.kitty': 'Kitty', 'tool.open_kitty': 'Kitty-Ordner öffnen', 'ks.presets': 'Presets', 'ks.look': 'Aussehen', 'ks.font': 'Schrift', 'ks.cursor': 'Cursor & Animation', 'ks.tabs': 'Tabs', 'ks.colors': 'Farben', 'ks.behavior': 'Verhalten', 'kp.mine': '01', 'kp.tokyo': 'Tokyo Night', 'kp.catppuccin': 'Catppuccin', 'kp.nord': 'Nord', 'kp.dracula': 'Dracula', 'kp.gruvbox': 'Gruvbox', 'kp.rosepine': 'Rosé Pine', 'kp.everforest': 'Everforest', 'kp.onedark': 'One Dark', 'kp.glass': 'Glas', 'kp.solid': 'Undurchsichtig', 'kp.retro': 'Retro', 'kc.trans': 'Transparenz', 'kc.window': 'Fenster', 'kc.cursor': 'Cursor', 'kc.anim': 'Animation', 'kc.tabs': 'Tabs', 'kc.palette': 'Farbpalette (16 Farben)', 'kc.behavior': 'Verhalten', 'k.opacity': 'Deckkraft', 'k.dynamic': 'Deckkraft live änderbar', 'k.blur': 'Unschärfe', 'k.padding': 'Innenabstand', 'k.decorations': 'Titelleiste', 'kdec.no': 'Zeigen', 'kdec.titlebar-only': 'Ohne Titelleiste', 'kdec.yes': 'Ganz aus', 'k.display': 'Anzeige-Server', 'kds.auto': 'Auto', 'kds.wayland': 'Wayland', 'kds.x11': 'X11', 'k.ligatures': 'Ligaturen aus', 'klig.never': 'Nie', 'klig.cursor': 'Am Cursor', 'klig.always': 'Immer', 'k.cursor_shape': 'Form', 'kcur.block': 'Block', 'kcur.beam': 'Strich', 'kcur.underline': 'Unterstrich', 'k.blink': 'Blinken', 'k.blink_curve': 'Blink-Kurve', 'kcurve.linear': 'Linear', 'kcurve.ease-in-out': 'Weich', 'kcurve.ease-in': 'Einblenden', 'kcurve.ease-out': 'Ausblenden', 'kcurve.step-end': 'Hart', 'k.trail': 'Cursor-Spur', 'k.decay_fast': 'Spur schnell weg', 'k.decay_slow': 'Spur langsam weg', 'k.bell_flash': 'Aufblitzen bei Glocke', 'k.tab_style': 'Tab-Stil', 'ktab.powerline': 'Powerline', 'ktab.slant': 'Schräg', 'ktab.fade': 'Verlauf', 'ktab.separator': 'Trenner', 'ktab.hidden': 'Aus', 'k.tab_powerline': 'Powerline-Form', 'kpl.slanted': 'Schräg', 'kpl.angled': 'Pfeil', 'kpl.round': 'Rund', 'k.tab_title': 'Tab-Titel', 'k.bg': 'Hintergrund', 'k.fg': 'Text', 'k.cursor': 'Cursor', 'k.sel_bg': 'Auswahl', 'k.sel_fg': 'Auswahl-Text', 'k.url': 'Links', 'k.tab_active_bg': 'Aktiver Tab', 'k.tab_active_fg': 'Aktiver Tab Text', 'k.tab_inactive_bg': 'Tab-Leiste', 'k.tab_inactive_fg': 'Inaktiver Tab Text', 'k.scrollback': 'Verlauf (Zeilen)', 'k.url_style': 'Link-Unterstrich', 'kurl.curly': 'Wellig', 'kurl.straight': 'Gerade', 'kurl.double': 'Doppelt', 'kurl.dotted': 'Gepunktet', 'kurl.dashed': 'Gestrichelt', 'kurl.none': 'Keiner', 'k.copy': 'Markieren kopiert', 'k.audio_bell': 'Ton bei Glocke', 'k.confirm': 'Schließen bestätigen', 'kconf.0': 'Nie', 'kconf.1': 'Immer', 'kconf.-1': 'Wenn etwas läuft', 'tip.k.dynamic': 'Mit Strg+Shift+A, dann M/L die Deckkraft im laufenden Kitty ändern', 'tip.k.blur': 'Unter Hyprland macht die Unschärfe Hyprland selbst (Effekte › Unschärfe)', 'tip.k.display': 'Dein Preset nutzt X11 (Workaround von KDE); unter Hyprland reicht Auto', 'tip.k.blink': '0 = Cursor blinkt nicht', 'tip.k.trail': 'Cursor zieht beim Springen eine Spur (0 = aus)', 'k.missing': 'Kitty ist nicht installiert – Config wird trotzdem geschrieben', 'k.reload': 'offene Kitty-Fenster laden neu (Transparenz evtl. erst nach Neustart)'})
TEXT["en"].update({'sec.kitty': 'Kitty', 'tool.open_kitty': 'Open Kitty folder', 'ks.presets': 'Presets', 'ks.look': 'Look', 'ks.font': 'Font', 'ks.cursor': 'Cursor & animation', 'ks.tabs': 'Tabs', 'ks.colors': 'Colours', 'ks.behavior': 'Behaviour', 'kp.mine': '01', 'kp.tokyo': 'Tokyo Night', 'kp.catppuccin': 'Catppuccin', 'kp.nord': 'Nord', 'kp.dracula': 'Dracula', 'kp.gruvbox': 'Gruvbox', 'kp.rosepine': 'Rosé Pine', 'kp.everforest': 'Everforest', 'kp.onedark': 'One Dark', 'kp.glass': 'Glass', 'kp.solid': 'Opaque', 'kp.retro': 'Retro', 'kc.trans': 'Transparency', 'kc.window': 'Window', 'kc.cursor': 'Cursor', 'kc.anim': 'Animation', 'kc.tabs': 'Tabs', 'kc.palette': 'Palette (16 colours)', 'kc.behavior': 'Behaviour', 'k.opacity': 'Opacity', 'k.dynamic': 'Opacity changeable live', 'k.blur': 'Blur', 'k.padding': 'Padding', 'k.decorations': 'Title bar', 'kdec.no': 'Show', 'kdec.titlebar-only': 'No title bar', 'kdec.yes': 'All off', 'k.display': 'Display server', 'kds.auto': 'Auto', 'kds.wayland': 'Wayland', 'kds.x11': 'X11', 'k.ligatures': 'Disable ligatures', 'klig.never': 'Never', 'klig.cursor': 'At cursor', 'klig.always': 'Always', 'k.cursor_shape': 'Shape', 'kcur.block': 'Block', 'kcur.beam': 'Beam', 'kcur.underline': 'Underline', 'k.blink': 'Blink', 'k.blink_curve': 'Blink curve', 'kcurve.linear': 'Linear', 'kcurve.ease-in-out': 'Smooth', 'kcurve.ease-in': 'Ease in', 'kcurve.ease-out': 'Ease out', 'kcurve.step-end': 'Hard', 'k.trail': 'Cursor trail', 'k.decay_fast': 'Trail fades fast', 'k.decay_slow': 'Trail fades slow', 'k.bell_flash': 'Flash on bell', 'k.tab_style': 'Tab style', 'ktab.powerline': 'Powerline', 'ktab.slant': 'Slant', 'ktab.fade': 'Fade', 'ktab.separator': 'Separator', 'ktab.hidden': 'Off', 'k.tab_powerline': 'Powerline shape', 'kpl.slanted': 'Slanted', 'kpl.angled': 'Arrow', 'kpl.round': 'Round', 'k.tab_title': 'Tab title', 'k.bg': 'Background', 'k.fg': 'Text', 'k.cursor': 'Cursor', 'k.sel_bg': 'Selection', 'k.sel_fg': 'Selection text', 'k.url': 'Links', 'k.tab_active_bg': 'Active tab', 'k.tab_active_fg': 'Active tab text', 'k.tab_inactive_bg': 'Tab bar', 'k.tab_inactive_fg': 'Inactive tab text', 'k.scrollback': 'Scrollback (lines)', 'k.url_style': 'Link underline', 'kurl.curly': 'Curly', 'kurl.straight': 'Straight', 'kurl.double': 'Double', 'kurl.dotted': 'Dotted', 'kurl.dashed': 'Dashed', 'kurl.none': 'None', 'k.copy': 'Copy on select', 'k.audio_bell': 'Bell sound', 'k.confirm': 'Confirm close', 'kconf.0': 'Never', 'kconf.1': 'Always', 'kconf.-1': 'If something runs', 'tip.k.dynamic': 'Ctrl+Shift+A, then M/L changes the opacity in a running Kitty', 'tip.k.blur': 'On Hyprland, Hyprland does the blur itself (Effects › Blur)', 'tip.k.display': 'Your preset uses X11 (a KDE workaround); on Hyprland Auto is enough', 'tip.k.blink': "0 = cursor doesn't blink", 'tip.k.trail': 'The cursor leaves a trail when jumping (0 = off)', 'k.missing': 'Kitty is not installed – the config is written anyway', 'k.reload': 'open Kitty windows reload (transparency may need a restart)'})

TEXT["de"].update({'up.save': 'Als eigenes Preset speichern', 'up.import': 'Preset importieren …', 'up.mine': 'Eigene', 'up.builtin': 'Mitgeliefert', 'up.name': 'Name', 'up.title': 'Eigene Presets', 'up.overwrite': '„{name}“ gibt es schon. Überschreiben?', 'up.saved': 'Gespeichert: {name}', 'up.update': 'Mit aktuellem Stand überschreiben', 'up.rename': 'Umbenennen …', 'up.export': 'Als Datei exportieren …', 'up.remove': 'Entfernen', 'up.remove_q': 'Eigenes Preset „{name}“ entfernen?', 'up.exported': 'Exportiert: {path}', 'up.imported': 'Importiert: {name}', 'up.badfile': 'Datei passt nicht zu diesem Bereich', 'up.tip': 'Klick: laden · Rechtsklick: umbenennen, exportieren, entfernen', 'up.load': 'Laden: {name}', 'up.save_binds': 'Aktuelle Kürzel als Set speichern …', 'up.remove_set': 'Eigenes Set entfernen'})
TEXT["en"].update({'up.save': 'Save as own preset', 'up.import': 'Import preset …', 'up.mine': 'Mine', 'up.builtin': 'Built-in', 'up.name': 'Name', 'up.title': 'Own presets', 'up.overwrite': '“{name}” already exists. Overwrite?', 'up.saved': 'Saved: {name}', 'up.update': 'Overwrite with current settings', 'up.rename': 'Rename …', 'up.export': 'Export to file …', 'up.remove': 'Remove', 'up.remove_q': 'Remove own preset “{name}”?', 'up.exported': 'Exported: {path}', 'up.imported': 'Imported: {name}', 'up.badfile': "File doesn't belong to this section", 'up.tip': 'Click: load · right-click: rename, export, remove', 'up.load': 'Load: {name}', 'up.save_binds': 'Save current shortcuts as a set …', 'up.remove_set': 'Remove own set'})

TEXT["de"].update({"pkg.kitty": "Kitty", "pkgd.kitty": "Terminal (unter Sonstiges › Kitty anpassbar)"})
TEXT["en"].update({"pkg.kitty": "Kitty", "pkgd.kitty": "terminal (customise under More › Kitty)"})

TEXT["de"].update({'sec.workspaces': 'Arbeitsflächen', 'card.workspaces': 'Arbeitsflächen 1–10', 'workspaces_on': 'Regeln schreiben', 'tip.workspaces_on': 'Aus = Hypr Studio schreibt keine Arbeitsflächen-Regeln (deine eigenen bleiben)', 'ws.std': 'Std', 'ws.name_ph': 'Name', 'ws.any': 'jeder Monitor', 'ws.name': 'Name (erscheint z. B. in der Waybar)', 'ws.monitor': 'Monitor, auf dem die Fläche liegt', 'ws.persistent': 'Immer da', 'ws.default': 'Start', 'tip.ws.persistent': 'Fläche bleibt bestehen, auch wenn sie leer ist', 'tip.ws.default': 'Start-Fläche für ihren Monitor', 'ws.no_rounding': 'Ecken aus', 'ws.layout': 'Layout', 'ws.layout_std': 'Standard', 'ws.on_empty': 'Beim Öffnen starten …', 'tip.ws.on_empty': 'Befehl, der startet, wenn die Fläche leer geöffnet wird (z. B. firefox)', 'ws.more': 'Mehr', 'border_size': 'Rahmen'})
TEXT["en"].update({'sec.workspaces': 'Workspaces', 'card.workspaces': 'Workspaces 1–10', 'workspaces_on': 'Write rules', 'tip.workspaces_on': 'Off = Hypr Studio writes no workspace rules (yours stay)', 'ws.std': 'Def', 'ws.name_ph': 'Name', 'ws.any': 'any monitor', 'ws.name': 'Name (shown e.g. in Waybar)', 'ws.monitor': 'Monitor the workspace lives on', 'ws.persistent': 'Persistent', 'ws.default': 'Start', 'tip.ws.persistent': 'Workspace stays even when empty', 'tip.ws.default': 'Start workspace for its monitor', 'ws.no_rounding': 'No rounding', 'ws.layout': 'Layout', 'ws.layout_std': 'Default', 'ws.on_empty': 'Run when opened …', 'tip.ws.on_empty': 'Command that starts when the workspace opens empty (e.g. firefox)', 'ws.more': 'More', 'border_size': 'Border'})

TEXT["de"].update({"ws.h_name": "Name", "ws.h_monitor": "Monitor"})
TEXT["en"].update({"ws.h_name": "Name", "ws.h_monitor": "Monitor"})

TEXT["de"].update({'sec.editor': 'Editor', 'card.editor': 'Leiste anordnen', 'ed.palette': 'Verfügbare Module', 'ed.all_used': 'Alle Module sind auf der Leiste', 'ed.move_left': 'Nach links', 'ed.move_center': 'In die Mitte', 'ed.move_right': 'Nach rechts', 'tip.editor': 'Module ziehen: auf der Leiste verschieben, aus „Verfügbare Module“ hinzufügen, von der Leiste wegziehen = entfernen · Rechtsklick: mehr', 'wb.enabled': 'Waybar an', 'wb.on': 'Waybar läuft', 'wb.off': 'Waybar ist aus (auch kein Autostart mehr)', 'wb.install': 'Waybar installieren', 'launcher.install': '{app} installieren'})
TEXT["en"].update({'sec.editor': 'Editor', 'card.editor': 'Arrange the bar', 'ed.palette': 'Available modules', 'ed.all_used': 'All modules are on the bar', 'ed.move_left': 'Move left', 'ed.move_center': 'Move to centre', 'ed.move_right': 'Move right', 'tip.editor': 'Drag modules: move them on the bar, add from “Available modules”, drag off the bar = remove · right-click: more', 'wb.enabled': 'Waybar on', 'wb.on': 'Waybar is running', 'wb.off': 'Waybar is off (no autostart either)', 'wb.install': 'Install Waybar', 'launcher.install': 'Install {app}'})

TEXT["de"].update({'sec.wallpaper': 'Hintergrundbild', 'sec.cursor': 'Mauszeiger', 'gate.missing': '{name} ist nicht installiert', 'gate.install': '{name} installieren', 'gate.launcher': '{name} ist nicht installiert – installieren oder einen anderen nehmen', 'gate.use': 'Verwenden', 'gate.install_short': 'Installieren', 'pkg.hyprcursor': 'Hyprcursor', 'pkgd.hyprcursor': 'moderne Mauszeiger-Themes für Hyprland', 'pkgd.hyprpaper': 'Hintergrundbild', 'paper.all': 'Alle Monitore', 'paper.per_monitor': 'Pro Monitor', 'paper.extra': 'Diashow & Sonstiges', 'paper.none': 'Kein Bild gewählt', 'paper.image': 'Bild wählen …', 'paper.folder': 'Ordner wählen (Diashow) …', 'paper.image_btn': 'Bild …', 'paper.folder_btn': 'Ordner …', 'paper.reset': 'Wie alle', 'paper.same': 'wie „Alle Monitore“', 'paper.fit': 'Anpassen', 'fit.cover': 'Füllen', 'fit.contain': 'Ganz zeigen', 'fit.fill': 'Strecken', 'fit.tile': 'Kacheln', 'paper.timeout': 'Wechsel alle', 'paper.random': 'Zufällige Reihenfolge', 'paper.recursive': 'Unterordner mitnehmen', 'paper.splash': 'Hyprland-Spruch zeigen', 'paper.autostart': 'Mit Hyprland starten', 'tip.paper.timeout': 'Nur bei Ordner (Diashow)', 'tip.paper.autostart': 'Trägt hyprpaper in den Hyprland-Autostart ein', 'paper.auto_hint': 'Autostart geändert – im Hyprland-Tab anwenden', 'paper.nopath': 'Erst ein Bild oder einen Ordner wählen', 'cur.title': 'Installierte Mauszeiger', 'cur.hyprcursor': 'Hyprcursor', 'cur.xcursor': 'XCursor', 'cur.none': 'Keine Mauszeiger-Themes gefunden (in ~/.local/share/icons ablegen)', 'cur.open': 'Themes-Ordner öffnen', 'cur.gtk': 'Auch für GTK-Apps', 'cur.picked': 'Gewählt: {name} – zum Übernehmen „Anwenden“', 'cur.done': 'Mauszeiger: {name}, {size} px'})
TEXT["en"].update({'sec.wallpaper': 'Wallpaper', 'sec.cursor': 'Cursor', 'gate.missing': '{name} is not installed', 'gate.install': 'Install {name}', 'gate.launcher': '{name} is not installed – install it or pick another one', 'gate.use': 'Use', 'gate.install_short': 'Install', 'pkg.hyprcursor': 'Hyprcursor', 'pkgd.hyprcursor': 'modern cursor themes for Hyprland', 'pkgd.hyprpaper': 'wallpaper', 'paper.all': 'All monitors', 'paper.per_monitor': 'Per monitor', 'paper.extra': 'Slideshow & more', 'paper.none': 'No image chosen', 'paper.image': 'Choose image …', 'paper.folder': 'Choose folder (slideshow) …', 'paper.image_btn': 'Image …', 'paper.folder_btn': 'Folder …', 'paper.reset': 'Like all', 'paper.same': 'like “All monitors”', 'paper.fit': 'Fit', 'fit.cover': 'Cover', 'fit.contain': 'Contain', 'fit.fill': 'Stretch', 'fit.tile': 'Tile', 'paper.timeout': 'Change every', 'paper.random': 'Random order', 'paper.recursive': 'Include subfolders', 'paper.splash': 'Show Hyprland splash', 'paper.autostart': 'Start with Hyprland', 'tip.paper.timeout': 'Only for folders (slideshow)', 'tip.paper.autostart': 'Adds hyprpaper to the Hyprland autostart', 'paper.auto_hint': 'Autostart changed – apply in the Hyprland tab', 'paper.nopath': 'Choose an image or folder first', 'cur.title': 'Installed cursors', 'cur.hyprcursor': 'Hyprcursor', 'cur.xcursor': 'XCursor', 'cur.none': 'No cursor themes found (put them in ~/.local/share/icons)', 'cur.open': 'Open themes folder', 'cur.gtk': 'Also for GTK apps', 'cur.picked': 'Picked: {name} – press Apply', 'cur.done': 'Cursor: {name}, {size} px'})

TEXT["de"].update({'lp.solid': 'Undurchsichtig', 'lp.solid_tokyo': 'Tokyo Night (deckend)', 'lp.solid_catppuccin': 'Catppuccin (deckend)', 'lp.solid_nord': 'Nord (deckend)'})
TEXT["en"].update({'lp.solid': 'Opaque', 'lp.solid_tokyo': 'Tokyo Night (opaque)', 'lp.solid_catppuccin': 'Catppuccin (opaque)', 'lp.solid_nord': 'Nord (opaque)'})

TEXT["de"].update({'adv.button': 'Erweiterte Einstellungen', 'adv.back': 'Zurück', 'adv.format': 'Hyprland-Config', 'fmtsw.conf': 'Alt (.conf)', 'fmtsw.lua': 'Neu (Lua)', 'tip.fmtsw.conf': 'hyprland.conf (hyprlang) – bis Hyprland 0.56, ab 0.57 nicht mehr unterstützt', 'tip.fmtsw.lua': 'hyprland.lua – ab Hyprland 0.55, ab 0.57 Pflicht', 'adv.found': 'Gefunden: {name}', 'adv.set': 'Hyprland-Config: {name}', 'nomain.lua': 'hyprland.lua fehlt – erst die Config auf Lua umstellen oder „Alt“ wählen', 'nomain.conf': 'hyprland.conf fehlt – „Neu (Lua)“ wählen'})
TEXT["en"].update({'adv.button': 'Advanced settings', 'adv.back': 'Back', 'adv.format': 'Hyprland config', 'fmtsw.conf': 'Old (.conf)', 'fmtsw.lua': 'New (Lua)', 'tip.fmtsw.conf': 'hyprland.conf (hyprlang) – up to Hyprland 0.56, no longer supported from 0.57', 'tip.fmtsw.lua': 'hyprland.lua – from Hyprland 0.55, required from 0.57', 'adv.found': 'Found: {name}', 'adv.set': 'Hyprland config: {name}', 'nomain.lua': 'hyprland.lua missing – convert your config to Lua first or choose “Old”', 'nomain.conf': 'hyprland.conf missing – choose “New (Lua)”'})

_lang = "en"


def set_lang(lang: str) -> None:
    global _lang
    _lang = lang if lang in TEXT else "de"


def t(key: str, **kw) -> str:
    s = TEXT[_lang].get(key) or TEXT["de"].get(key) or key
    return s.format(**kw) if kw else s
