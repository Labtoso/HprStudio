"""Hypr Studio – Hyprland und Waybar per Klick gestalten (LabtosoStudios)."""

__version__ = "1.5.0"
APP_ID = "de.labtosostudios.hyprstudio"
APP_NAME = "Hypr Studio"
