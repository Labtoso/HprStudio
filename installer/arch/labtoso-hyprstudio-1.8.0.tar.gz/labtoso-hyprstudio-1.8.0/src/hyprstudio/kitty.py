"""Kitty-Terminal: Zustand, Presets und ~/.config/kitty/hyprstudio.conf (per include in kitty.conf). Ohne Qt."""

import json
import shutil
from pathlib import Path

from . import model
from .model import MARK, norm

INCLUDE = "include hyprstudio.conf"

PALETTES = {  # 16 Farben: color0 … color15
    "tokyo": ["#15161e", "#f7768e", "#9ece6a", "#e0af68", "#7aa2f7", "#bb9af7", "#7dcfff", "#a9b1d6",
              "#414868", "#f7768e", "#9ece6a", "#e0af68", "#7aa2f7", "#bb9af7", "#7dcfff", "#c0caf5"],
    "catppuccin": ["#45475a", "#f38ba8", "#a6e3a1", "#f9e2af", "#89b4fa", "#f5c2e7", "#94e2d5", "#bac2de",
                   "#585b70", "#f38ba8", "#a6e3a1", "#f9e2af", "#89b4fa", "#f5c2e7", "#94e2d5", "#a6adc8"],
    "nord": ["#3b4252", "#bf616a", "#a3be8c", "#ebcb8b", "#81a1c1", "#b48ead", "#88c0d0", "#e5e9f0",
             "#4c566a", "#bf616a", "#a3be8c", "#ebcb8b", "#81a1c1", "#b48ead", "#8fbcbb", "#eceff4"],
    "dracula": ["#21222c", "#ff5555", "#50fa7b", "#f1fa8c", "#bd93f9", "#ff79c6", "#8be9fd", "#f8f8f2",
                "#6272a4", "#ff6e6e", "#69ff94", "#ffffa5", "#d6acff", "#ff92df", "#a4ffff", "#ffffff"],
    "gruvbox": ["#282828", "#cc241d", "#98971a", "#d79921", "#458588", "#b16286", "#689d6a", "#a89984",
                "#928374", "#fb4934", "#b8bb26", "#fabd2f", "#83a598", "#d3869b", "#8ec07c", "#ebdbb2"],
    "rosepine": ["#26233a", "#eb6f92", "#31748f", "#f6c177", "#9ccfd8", "#c4a7e7", "#ebbcba", "#e0def4",
                 "#6e6a86", "#eb6f92", "#31748f", "#f6c177", "#9ccfd8", "#c4a7e7", "#ebbcba", "#e0def4"],
    "everforest": ["#475258", "#e67e80", "#a7c080", "#dbbc7f", "#7fbbb3", "#d699b6", "#83c092", "#d3c6aa",
                   "#475258", "#e67e80", "#a7c080", "#dbbc7f", "#7fbbb3", "#d699b6", "#83c092", "#d3c6aa"],
    "onedark": ["#282c34", "#e06c75", "#98c379", "#e5c07b", "#61afef", "#c678dd", "#56b6c2", "#abb2bf",
                "#5c6370", "#e06c75", "#98c379", "#e5c07b", "#61afef", "#c678dd", "#56b6c2", "#ffffff"],
    "retro": ["#000000", "#ff5555", "#33ff66", "#ffcc00", "#3399ff", "#cc66ff", "#33cccc", "#b0ffb0",
              "#335533", "#ff7777", "#66ff99", "#ffe066", "#66b3ff", "#dd99ff", "#66e0e0", "#e0ffe0"],
}

KITTY_DEFAULT = {
    # Farben
    "palette": PALETTES["tokyo"], "fg": "#c0caf5", "bg": "#1a1b26", "cursor": "#c0caf5", "sel_fg": "#1a1b26",
    "sel_bg": "#7aa2f7", "url": "#7dcfff", "tab_active_fg": "#1a1b26", "tab_active_bg": "#7aa2f7",
    "tab_inactive_fg": "#787c99", "tab_inactive_bg": "#16161e",
    # Aussehen
    "opacity": 0.85, "dynamic_opacity": True, "blur": 32, "padding": 14, "decorations": "no",
    "display_server": "auto",
    # Schrift
    "font": "JetBrainsMono Nerd Font", "font_size": 11.5, "ligatures": "never",
    # Cursor & Animation
    "cursor_shape": "beam", "blink": 0.0, "blink_curve": "ease-in-out", "trail": 3, "trail_decay_fast": 0.1,
    "trail_decay_slow": 0.4, "bell_flash": False,
    # Tabs
    "tab_edge": "bottom", "tab_style": "powerline", "tab_powerline": "slanted", "tab_title": "{index}: {title}",
    # Verhalten
    "confirm_close": 0, "audio_bell": False, "scrollback": 10000, "url_style": "curly", "copy_on_select": False,
}
LOOK = ("palette", "fg", "bg", "cursor", "sel_fg", "sel_bg", "url", "tab_active_fg", "tab_active_bg",
        "tab_inactive_fg", "tab_inactive_bg", "opacity", "blur", "padding", "cursor_shape", "trail", "tab_style",
        "tab_powerline")


def _theme(pal: str, fg: str, bg: str, accent: str, tab_bg: str, muted: str, url: str | None = None) -> dict:
    p = PALETTES[pal]
    return {"palette": p, "fg": fg, "bg": bg, "cursor": fg, "sel_fg": bg, "sel_bg": accent, "url": url or p[6],
            "tab_active_fg": bg, "tab_active_bg": accent, "tab_inactive_fg": muted, "tab_inactive_bg": tab_bg}


PRESETS = {
    # Sebastians Kitty-Config vom 2026-10-18 (Vault: Skripte/Kitty Config) – genau so
    "mine": {"display_server": "x11"},
    "tokyo": {},
    "catppuccin": _theme("catppuccin", "#cdd6f4", "#1e1e2e", "#cba6f7", "#181825", "#7f849c"),
    "nord": _theme("nord", "#d8dee9", "#2e3440", "#88c0d0", "#3b4252", "#7b88a1") | {"cursor_shape": "block"},
    "dracula": _theme("dracula", "#f8f8f2", "#282a36", "#bd93f9", "#21222c", "#6272a4"),
    "gruvbox": _theme("gruvbox", "#ebdbb2", "#282828", "#fabd2f", "#1d2021", "#928374") | {
        "cursor_shape": "block", "tab_style": "slant"},
    "rosepine": _theme("rosepine", "#e0def4", "#191724", "#ebbcba", "#1f1d2e", "#6e6a86") | {"tab_powerline": "round"},
    "everforest": _theme("everforest", "#d3c6aa", "#2d353b", "#a7c080", "#272e33", "#859289"),
    "onedark": _theme("onedark", "#abb2bf", "#282c34", "#61afef", "#21252b", "#5c6370"),
    "glass": {"opacity": 0.6, "blur": 48, "padding": 18, "trail": 3},
    "solid": {"opacity": 1.0, "blur": 0, "trail": 0, "tab_style": "fade"},
    "retro": _theme("retro", "#33ff66", "#000000", "#33ff66", "#001100", "#227733") | {
        "opacity": 0.95, "blur": 0, "cursor_shape": "block", "trail": 0, "tab_style": "separator", "padding": 8},
}


def _copy(d):
    return json.loads(json.dumps(d))


def state(saved: dict | None) -> dict:
    s = _copy(KITTY_DEFAULT)
    for k, v in (saved or {}).items():
        if k not in s:
            continue
        if k == "palette":
            if isinstance(v, list) and len(v) == 16 and all(isinstance(x, str) for x in v):
                s[k] = v
        elif type(v) is type(s[k]):
            s[k] = v
        elif isinstance(s[k], float) and type(v) is int:
            s[k] = float(v)
    return s


def preset(name: str, base: dict | None = None) -> dict:
    s = state(base)
    for k in LOOK + ("display_server",):
        s[k] = _copy(KITTY_DEFAULT[k])
    s.update(_copy(PRESETS.get(name, {})))
    return s


def _c(x: str) -> str:
    return norm(x)[:7]


def _num(v) -> str:
    return model._num(v) if not isinstance(v, bool) else ("yes" if v else "no")


def conf(s: dict) -> str:
    yn = lambda b: "yes" if b else "no"  # noqa: E731
    blink = "0" if not s["blink"] else f"{_num(float(s['blink']))} {s['blink_curve']}"
    lines = [
        f"# {MARK} – automatisch erzeugt, wird beim Anwenden überschrieben",
        "",
        "# Schrift",
        f"font_family        {s['font']}",
        f"font_size          {_num(float(s['font_size']))}",
        f"disable_ligatures  {s['ligatures']}",
        "",
        "# Transparenz",
        f"background_opacity          {_num(float(s['opacity']))}",
        f"dynamic_background_opacity  {yn(s['dynamic_opacity'])}",
        f"background_blur             {s['blur']}",
    ]
    if s["display_server"] != "auto":
        lines.append(f"linux_display_server        {s['display_server']}")
    lines += [
        "",
        "# Fenster",
        f"hide_window_decorations  {s['decorations']}",
        f"window_padding_width     {s['padding']}",
        f"confirm_os_window_close  {s['confirm_close']}",
        f"enable_audio_bell        {yn(s['audio_bell'])}",
        f"visual_bell_duration     {'0.2 ease-out' if s['bell_flash'] else '0'}",
        f"scrollback_lines         {s['scrollback']}",
        f"url_style                {s['url_style']}",
        f"copy_on_select           {'clipboard' if s['copy_on_select'] else 'no'}",
        "",
        "# Cursor & Animation",
        f"cursor_shape             {s['cursor_shape']}",
        f"cursor_blink_interval    {blink}",
        f"cursor_trail             {s['trail']}",
        f"cursor_trail_decay       {_num(float(s['trail_decay_fast']))} {_num(float(s['trail_decay_slow']))}",
        "",
        "# Tabs",
        f"tab_bar_edge          {s['tab_edge']}",
        f"tab_bar_style         {s['tab_style']}",
        f"tab_powerline_style   {s['tab_powerline']}",
        f'tab_title_template    "{s["tab_title"]}"',
        "",
        "# Farben",
        f"foreground            {_c(s['fg'])}",
        f"background            {_c(s['bg'])}",
        f"selection_foreground  {_c(s['sel_fg'])}",
        f"selection_background  {_c(s['sel_bg'])}",
        f"cursor                {_c(s['cursor'])}",
        f"url_color             {_c(s['url'])}",
        f"active_tab_foreground   {_c(s['tab_active_fg'])}",
        f"active_tab_background   {_c(s['tab_active_bg'])}",
        f"inactive_tab_foreground {_c(s['tab_inactive_fg'])}",
        f"inactive_tab_background {_c(s['tab_inactive_bg'])}",
        "",
    ]
    lines += [f"color{i:<2} {_c(c)}" for i, c in enumerate(s["palette"])]
    return "\n".join(lines) + "\n"


def kdir(cfg_home: Path) -> Path:
    return cfg_home / "kitty"


def apply(s: dict, cfg_home: Path, log) -> tuple[bool, str]:
    d = kdir(cfg_home)
    d.mkdir(parents=True, exist_ok=True)
    own = d / "hyprstudio.conf"
    model._keep_previous(own)
    own.write_text(conf(s), encoding="utf-8")
    log(f"→ {own}")
    main = d / "kitty.conf"
    text = main.read_text(encoding="utf-8", errors="replace") if main.is_file() else ""
    if not any(ln.strip() == INCLUDE for ln in text.splitlines()):
        if main.is_file():
            bak = main.with_name("kitty.conf.hyprstudio-original")
            if not bak.exists():
                shutil.copy2(main, bak)
                log(f"Sicherung: {bak}")
        with open(main, "a", encoding="utf-8") as fh:
            fh.write(("\n" if text and not text.endswith("\n") else "") + f"\n# {MARK}\n{INCLUDE}\n")
        log(f"+ {main}: {INCLUDE}")
    # laufende Kitty-Fenster laden die Config neu (SIGUSR1)
    model.run(["pkill", "-USR1", "-x", "kitty"], log, quiet=True)
    return True, ""


def undo(cfg_home: Path, log) -> bool:
    ok = model.undo_file(kdir(cfg_home) / "hyprstudio.conf")
    if ok:
        model.run(["pkill", "-USR1", "-x", "kitty"], log, quiet=True)
    return ok


def remove_include(cfg_home: Path, log) -> bool:
    main = kdir(cfg_home) / "kitty.conf"
    if not main.is_file():
        return False
    lines = main.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
    keep = [ln for ln in lines if ln.strip() not in (INCLUDE, f"# {MARK}")]
    if len(keep) == len(lines):
        return False
    shutil.copy2(main, model.stamp(main))
    main.write_text("".join(keep), encoding="utf-8")
    log(f"Einbindung entfernt: {main}")
    return True
